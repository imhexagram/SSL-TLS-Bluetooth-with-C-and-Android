package com.example.ssl_bluetooth;

import androidx.appcompat.app.AppCompatActivity;
import androidx.core.app.ActivityCompat;

import android.Manifest;
import android.bluetooth.BluetoothAdapter;
import android.bluetooth.BluetoothDevice;
import android.bluetooth.BluetoothServerSocket;
import android.bluetooth.BluetoothSocket;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.util.Set;
import java.util.UUID;

public class MainActivity extends AppCompatActivity {

    private MyBluetoothService myBluetoothService;
    private MyBluetoothService.ConnectedThread connectedThread;
    private InputStream inputStream;
    private OutputStream outputStream;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        BluetoothAdapter adapter = BluetoothAdapter.getDefaultAdapter();
        if (adapter == null) {
            Toast.makeText(MainActivity.this, "No Bluetooth Device Found", Toast.LENGTH_SHORT).show();
            finish();
        } else {
            if (!adapter.isEnabled()) {
                if (ActivityCompat.checkSelfPermission(this, Manifest.permission.BLUETOOTH_CONNECT) != PackageManager.PERMISSION_GRANTED) {
                    ActivityCompat.requestPermissions(this, new String[]{Manifest.permission.BLUETOOTH_CONNECT},123);
                    return;
                }
                Intent enableBtIntent = new Intent(BluetoothAdapter.ACTION_REQUEST_ENABLE);
                startActivity(enableBtIntent);
            }
        }

        Set<BluetoothDevice> pairedDevices = adapter.getBondedDevices();
        if (pairedDevices.size() > 0) {
            // There are paired devices. Get the name and address of each paired device.
            for (BluetoothDevice device : pairedDevices) {
                String deviceName = device.getName();
                String deviceHardwareAddress = device.getAddress(); // MAC address
                Log.d("MTAG", deviceName + deviceHardwareAddress);
            }
        }

        UUID MY_UUID = UUID.fromString("12345678-0000-0000-0000-123456789abc");
        BluetoothSocket msocket;
        BluetoothSocket tmp = null;
        BluetoothDevice device = adapter.getRemoteDevice("30:03:C8:AC:9F:50");
        Log.d("MTAG","Connect to "+device.getName());
        try {
            tmp = device.createRfcommSocketToServiceRecord(MY_UUID);
        } catch (IOException e) {
            Log.e("MTAG","Socket create failed", e);
        }
        msocket = tmp;
        try {
            msocket.connect();
        } catch (IOException connectException) {
            try {
                msocket.close();
            } catch (IOException closeException) {
                Log.e("MTAG","Could not close client socket", closeException);
            }
        }
        /***
        myBluetoothService = new MyBluetoothService();
        connectedThread = myBluetoothService.new ConnectedThread(msocket);
        TextView receive = findViewById(R.id.recv);
        connectedThread.run(receive);
         ***/
        try {
            inputStream = msocket.getInputStream();
            outputStream = msocket.getOutputStream();
        } catch (IOException e) {
            Log.e("MTAG","Could not create stream", e);
        }
        startListening(this.getCurrentFocus());
    }

    public void send(View view){
        EditText sendText = findViewById(R.id.sendText);
        String userInput = sendText.getText().toString();
        Toast.makeText(MainActivity.this, userInput, Toast.LENGTH_SHORT).show();
        //connectedThread.write(userInput.getBytes());
        try{
            outputStream.write(userInput.getBytes());
            Log.d("MTAG", userInput);
        } catch (IOException e) {
            Log.e("MTAG", "Could not send message");
        }
        TextView sent = findViewById(R.id.sent);
        sent.setText(sent.getText().toString()+"\n"+userInput);
        sendText.getText().clear();
    }

    private void startListening(View view){
        new Thread(new Runnable() {
            @Override
            public void run() {
                while(true){
                    try{
                        byte[] buffer = new byte[1024];
                        int bytesRead = inputStream.read(buffer);
                        String recvMsg = new String(buffer);
                        TextView recv = findViewById(R.id.recv);
                        recv.setText(recv.getText().toString()+"\n"+recvMsg);
                        Log.d("MTAG",recvMsg);
                    } catch (Exception e) {
                        //Log.e("MTAG", "Could not recv message");
                    }
                }
            }
        }).start();
    }

}