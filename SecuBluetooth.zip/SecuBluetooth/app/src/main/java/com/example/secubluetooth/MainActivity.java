package com.example.secubluetooth;

import androidx.appcompat.app.AppCompatActivity;
import androidx.core.app.ActivityCompat;

import android.Manifest;
import android.bluetooth.BluetoothAdapter;
import android.bluetooth.BluetoothDevice;
import android.bluetooth.BluetoothSocket;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.os.AsyncTask;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.io.OutputStream;
import java.lang.reflect.InvocationTargetException;
import java.lang.reflect.Method;
import java.nio.charset.StandardCharsets;
import java.util.UUID;
import java.util.Set;

public class MainActivity extends AppCompatActivity {

    private BluetoothAdapter bluetoothAdapter;
    private BluetoothSocket bluetoothSocket;
    private InputStream inputStream;
    private OutputStream outputStream;
    private static final String TAG = "MTAG";

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        bluetoothAdapter = BluetoothAdapter.getDefaultAdapter();
        if (bluetoothAdapter == null) {
            Toast.makeText(MainActivity.this, "No Bluetooth Device Found", Toast.LENGTH_SHORT).show();
            finish();
        } else {
            if (!bluetoothAdapter.isEnabled()) {
                if (ActivityCompat.checkSelfPermission(this, android.Manifest.permission.BLUETOOTH_CONNECT) != PackageManager.PERMISSION_GRANTED) {
                    ActivityCompat.requestPermissions(this, new String[]{Manifest.permission.BLUETOOTH_CONNECT}, 123);
                    return;
                }
                Intent enableBtIntent = new Intent(BluetoothAdapter.ACTION_REQUEST_ENABLE);
                startActivity(enableBtIntent);
            }
        }

        checkDevices(bluetoothAdapter);

        BluetoothDevice device = bluetoothAdapter.getRemoteDevice("30:03:C8:AC:9F:50");
        try {
            Method m = device.getClass().getMethod("createRfcommSocket", new Class[]{int.class});
            bluetoothSocket = (BluetoothSocket) m.invoke(device, 20);
            ConnectThread connectThread = new ConnectThread(bluetoothSocket);
            connectThread.start();
            inputStream = connectThread.getInputStream();
            outputStream = connectThread.getOutputStream();
        } catch (NoSuchMethodException | InvocationTargetException | IllegalAccessException e) {
            Log.e(TAG, "Error", e);
            throw new RuntimeException(e);
        } catch (IOException e) {
            Log.e(TAG,"Get Stream Failed", e);
        }
        /***
        TextView received = findViewById(R.id.recv);
        BufferedReader bufferedReader = new BufferedReader(new InputStreamReader(inputStream));
        while(true){
            String recvMsg = null;
            try {
                recvMsg = bufferedReader.readLine();
            } catch (IOException e) {
                Log.e(TAG,"Cant Read Message");
                throw new RuntimeException(e);
            }
            if(recvMsg.length() > 0){
                Log.d(TAG,"Recv : "+recvMsg);
                received.setText(received.getText().toString()+"\n"+recvMsg);
            }else{
                break;
            }
        }
         ***/
    }

    private class ConnectThread extends Thread {
        private BluetoothSocket socket;
        private boolean activeConnect;

        public ConnectThread(BluetoothSocket bluetoothSocket) {
            this.socket = bluetoothSocket;
        }

        public void run() {
            try {
                if (ActivityCompat.checkSelfPermission(MainActivity.this, Manifest.permission.BLUETOOTH_CONNECT) != PackageManager.PERMISSION_GRANTED) {
                    ActivityCompat.requestPermissions(MainActivity.this, new String[]{Manifest.permission.BLUETOOTH_CONNECT}, 123);
                    //return;
                }
                socket.connect();
                Log.d(TAG, "Connected");
            } catch (IOException e) {
                Log.e(TAG, "Error connecting to server", e);
            }

            try {
                inputStream = socket.getInputStream();

            byte[] buffer = new byte[1024];
            int bytes;
            while(true){
                bytes = inputStream.read(buffer);
                if (bytes > 0){
                    final byte[] data = new byte[bytes];
                    System.arraycopy(buffer, 0, data, 0, bytes);
                    String receivedString = new String(data, StandardCharsets.UTF_8);
                    Log.d(TAG,"Recv: "+receivedString);
                    TextView received = findViewById(R.id.recv);
                    received.post(new Runnable() {
                        @Override
                        public void run() {
                            received.setText(received.getText().toString()+"\n"+receivedString);
                        }
                    });
                }else{
                    break;
                }
            }
            } catch (IOException e) {
                throw new RuntimeException(e);
            }

        }
        public InputStream getInputStream() throws IOException {
            return socket.getInputStream();
        }

        public OutputStream getOutputStream() throws IOException {
            return socket.getOutputStream();
        }
    }

    private void checkDevices(BluetoothAdapter bluetoothAdapter) {
        assert bluetoothAdapter != null;
        if (ActivityCompat.checkSelfPermission(this, Manifest.permission.BLUETOOTH_CONNECT) != PackageManager.PERMISSION_GRANTED) {
            ActivityCompat.requestPermissions(this, new String[]{Manifest.permission.BLUETOOTH_CONNECT}, 123);
            return;
        }
        Set<BluetoothDevice> pairedDevices = bluetoothAdapter.getBondedDevices();
        if (pairedDevices.size() >0 ){
            for (BluetoothDevice device : pairedDevices){
                String deviceName = device.getName();;
                String deviceAddress = device.getAddress();
                Log.d(TAG, deviceName+" "+ deviceAddress);
            }
        }
    }

    public void send(View view){
        EditText sendText = findViewById(R.id.sendText);
        String userInput = sendText.getText().toString();
        Toast.makeText(MainActivity.this, userInput, Toast.LENGTH_SHORT).show();
        //connectedThread.write(userInput.getBytes());
        try{
            outputStream.write(userInput.getBytes());
            Log.d(TAG, "User Input : "+ userInput);
        } catch (IOException e) {
            Log.e(TAG, "Could not send message");
        }
        TextView sent = findViewById(R.id.sent);
        sent.setText(sent.getText().toString()+"\n"+userInput);
        sendText.getText().clear();
    }
}