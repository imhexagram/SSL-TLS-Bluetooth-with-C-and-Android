package com.example.sslbluetooth;


import android.bluetooth.BluetoothSocket;
import android.content.Context;
import android.content.res.AssetManager;
import android.util.Log;
import android.widget.TextView;

import java.io.BufferedInputStream;
import java.io.FileInputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.net.Socket;
import java.nio.ByteBuffer;
import java.security.KeyStore;
import java.security.SecureRandom;
import java.security.cert.Certificate;
import java.security.cert.CertificateFactory;

import javax.net.ssl.SSLContext;
import javax.net.ssl.SSLEngine;
import javax.net.ssl.SSLEngineResult;
import javax.net.ssl.SSLException;
import javax.net.ssl.SSLSession;
import javax.net.ssl.SSLSocket;
import javax.net.ssl.SSLSocketFactory;
import javax.net.ssl.TrustManagerFactory;

public class NioSslClient extends NioSslPeer{
    private static final String TAG = "MTAG";
    private final String remoteAddress;
    private final int port;
    private final SSLEngine engine;
    private final InputStream inputStream;
    private final OutputStream outputStream;
    public NioSslClient(BluetoothSocket btsocket, AssetManager assetManager, String protocol, String remoteAddress, int port) throws Exception{
        this.remoteAddress = remoteAddress;
        this.port = port;
        this.inputStream = btsocket.getInputStream();
        this.outputStream = btsocket.getOutputStream();
        try {
            SSLContext context = SSLContext.getInstance(protocol);
            context.init(createKeyManagers(assetManager,"client.bks", "kali$$", "kali$$"), createTrustManagers(assetManager,"caroot.bks", "kali$$"), new SecureRandom());
            /*
            CertificateFactory cf = CertificateFactory.getInstance("X.509");
            InputStream caInput = assetManager.open("caroot.crt");
            Certificate ca;
            try {
                ca = cf.generateCertificate(caInput);
            }finally {
                caInput.close();
            }
            KeyStore keyStore = KeyStore.getInstance(KeyStore.getDefaultType());
            keyStore.load(null,null);
            keyStore.setCertificateEntry("ca", ca);
            TrustManagerFactory tmf = TrustManagerFactory.getInstance(TrustManagerFactory.getDefaultAlgorithm());
            tmf.init(keyStore);
            context.init(null,tmf.getTrustManagers(),null);
            */

            this.engine = context.createSSLEngine("", 20);
            this.engine.setUseClientMode(true);

            SSLSession sslSession = this.engine.getSession();
            myNetData = ByteBuffer.allocate(sslSession.getPacketBufferSize());
            peerNetData = ByteBuffer.allocate(sslSession.getPacketBufferSize());
            myAppData = ByteBuffer.allocate(sslSession.getApplicationBufferSize());
            peerAppData = ByteBuffer.allocate(sslSession.getApplicationBufferSize());

        } catch (Exception e) {
            throw new RuntimeException(e);
        }
    }
    public boolean connect() throws Exception{
        engine.beginHandshake();
        return doHandshake(inputStream, outputStream, engine);
    }
    public void write(String message) throws IOException {
        write(outputStream, engine, message);
    }
    @Override
    protected void write(OutputStream outputStream, SSLEngine engine, String message) throws IOException {
        Log.d(TAG,"About to write to the server...");
        myAppData.clear();
        myAppData.put(message.getBytes());
        myAppData.flip();
        while (myAppData.hasRemaining()) {
            // The loop has a meaning for (outgoing) messages larger than 16KB.
            // Every wrap call will remove 16KB from the original message and send it to the remote peer.
            myNetData.clear();
            SSLEngineResult result = engine.wrap(myAppData, myNetData);
            switch (result.getStatus()) {
                case OK:
                    myNetData.flip();
                    while (myNetData.hasRemaining()) {
                        int limit = myNetData.limit();
                        byte[] data = new byte[limit];
                        myNetData.get(data, 0, limit);
                        outputStream.write(myNetData.array());
                        myNetData.position(limit);
                    }
                    Log.d(TAG,"Message sent to server: " + message);
                    break;
                case BUFFER_OVERFLOW:
                    myNetData = enlargePacketBuffer(engine, myNetData);
                    break;
                case BUFFER_UNDERFLOW:
                    throw new SSLException("Buffer underflow occured after a wrap. I don't think we should ever get here.");
                case CLOSED:
                    closeConnection(inputStream, outputStream, engine);
                    return;
                default:
                    throw new IllegalStateException("Invalid SSL status: " + result.getStatus());
            }
        }
    }

    public void read(TextView received) throws Exception {
        read(received, inputStream, engine);
    }
    @Override
    protected void read(TextView received, InputStream inputStream, SSLEngine engine) throws Exception  {
        Log.d(TAG,"About to read from the server...");

        peerNetData.clear();
        int waitToReadMillis = 50;
        boolean exitReadLoop = false;
        while (!exitReadLoop) {
            int bytesRead = inputStream.read(peerNetData.array());
            if (bytesRead > 0) {
                peerNetData.flip();
                while (peerNetData.hasRemaining()) {
                    peerAppData.clear();
                    SSLEngineResult result = engine.unwrap(peerNetData, peerAppData);
                    switch (result.getStatus()) {
                        case OK:
                            peerAppData.flip();
                            Log.d(TAG,"Server response: " + new String(peerAppData.array()));
                            exitReadLoop = true;

                            received.post(new Runnable() {
                                @Override
                                public void run() {
                                    received.setText(received.getText().toString()+new String(peerAppData.array()));
                                }
                            });
                            break;
                        case BUFFER_OVERFLOW:
                            peerAppData = enlargeApplicationBuffer(engine, peerAppData);
                            break;
                        case BUFFER_UNDERFLOW:
                            peerNetData = handleBufferUnderflow(engine, peerNetData);
                            break;
                        case CLOSED:
                            closeConnection(inputStream, outputStream, engine);
                            return;
                        default:
                            throw new IllegalStateException("Invalid SSL status: " + result.getStatus());
                    }
                }
            } else if (bytesRead < 0) {
                handleEndOfStream(inputStream, outputStream, engine);
                return;
            }
            Thread.sleep(waitToReadMillis);
        }
    }

    public void shutdown() throws IOException {
        Log.d(TAG,"About to close connection with the server...");
        closeConnection(inputStream, outputStream, engine);
        executor.shutdown();
        Log.d(TAG,"Goodbye!");
    }
}
