package com.example.sslbluetooth;

import android.content.Context;
import android.content.res.AssetManager;
import android.util.Log;
import android.widget.TextView;

import java.io.BufferedReader;
import java.io.FileInputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.io.OutputStream;
import java.nio.ByteBuffer;
import java.nio.channels.Channels;
import java.nio.channels.ReadableByteChannel;
import java.nio.channels.Selector;
import java.security.KeyStore;
import java.util.Arrays;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

import javax.net.ssl.KeyManager;
import javax.net.ssl.KeyManagerFactory;
import javax.net.ssl.SSLEngine;
import javax.net.ssl.SSLEngineResult;
import javax.net.ssl.SSLException;
import javax.net.ssl.TrustManager;
import javax.net.ssl.TrustManagerFactory;

public abstract class NioSslPeer {
    private static final String TAG = "MTAG";
    protected ByteBuffer myAppData;
    protected ByteBuffer peerAppData;
    protected ByteBuffer myNetData;
    protected ByteBuffer peerNetData;
    protected ExecutorService executor = Executors.newSingleThreadExecutor();

    protected abstract void read(TextView received, InputStream inputStream, SSLEngine engine) throws Exception;

    protected abstract void write(OutputStream outputStream, SSLEngine engine, String message) throws Exception;

    public boolean doHandshake(InputStream inputStream, OutputStream outputStream, SSLEngine engine) throws IOException {
        SSLEngineResult result;
        SSLEngineResult.HandshakeStatus handshakeStatus;
        int appBufferSize = engine.getSession().getApplicationBufferSize();
        myAppData = ByteBuffer.allocate(appBufferSize);
        peerAppData = ByteBuffer.allocate(appBufferSize);
        myNetData.clear();
        peerNetData.clear();

        handshakeStatus = engine.getHandshakeStatus();
        while (handshakeStatus != SSLEngineResult.HandshakeStatus.FINISHED && handshakeStatus != SSLEngineResult.HandshakeStatus.NOT_HANDSHAKING) {
            switch (handshakeStatus) {
                case NEED_UNWRAP : {
                    if(inputStream.available()>0) {
                        int b = inputStream.read(peerNetData.array());

                        Log.d(TAG, "PeerNetData Recv : " + b);
                        if (b < 0) {
                            if (engine.isInboundDone() && engine.isOutboundDone()) {
                                return false;
                            }
                            try {
                                engine.closeInbound();
                            } catch (SSLException e) {
                                Log.e(TAG, "This engine was forced to close inbound, without having received the proper SSL/TLS close notification message from the peer, due to end of stream.");
                            }
                            engine.closeOutbound();
                            // After closeOutbound the engine will be set to WRAP state, in order to try to send a close message to the client.
                            handshakeStatus = engine.getHandshakeStatus();
                            break;
                        }

                        peerNetData.position(b);
                        peerNetData.flip();
                    }
                    try {
                        result = engine.unwrap(peerNetData, peerAppData);
                        Log.d(TAG,"Unwraping..."+peerNetData.position()+"/"+peerNetData.limit());
                        /*
                        do{
                            result = engine.unwrap(peerNetData, peerAppData);
                            Log.d(TAG,"Unwraping..."+peerNetData.position()+"/"+peerNetData.limit());
                        }while(peerNetData.hasRemaining() || result.bytesProduced() >0);
                        */
                        peerNetData.compact();
                        handshakeStatus = result.getHandshakeStatus();
                        Log.d(TAG,"-----Unwraping Finished");
                    } catch (SSLException sslException) {
                        Log.e(TAG,"A problem was encountered while processing the data that caused the SSLEngine to abort. Will try to properly close connection...", sslException);
                        engine.closeOutbound();
                        handshakeStatus = engine.getHandshakeStatus();
                        break;
                    }
                    switch (result.getStatus()) {
                        case OK : {
                            break;
                        }
                        case BUFFER_OVERFLOW : // Will occur when peerAppData's capacity is smaller than the data derived from peerNetData's unwrap.
                            peerAppData = enlargeApplicationBuffer(engine, peerAppData);
                            break;
                        case BUFFER_UNDERFLOW : // Will occur either when no data was read from the peer or when the peerNetData buffer was too small to hold all peer's data.
                            peerNetData = handleBufferUnderflow(engine, peerNetData);
                            break;
                        case CLOSED : {
                            if (engine.isOutboundDone()) {
                                return false;
                            } else {
                                engine.closeOutbound();
                                handshakeStatus = engine.getHandshakeStatus();
                            }
                            break;
                        }
                        default : throw new IllegalStateException("Invalid SSL status: " + result.getStatus());
                    }
                    break;
                }
                case NEED_WRAP : {
                    myNetData.clear();
                    try {
                        result = engine.wrap(myAppData, myNetData);
                        handshakeStatus = result.getHandshakeStatus();
                    } catch (SSLException sslException) {
                        //  log.error("A problem was encountered while processing the data that caused the SSLEngine to abort. Will try to properly close connection...");
                        engine.closeOutbound();
                        handshakeStatus = engine.getHandshakeStatus();
                        break;
                    }
                    switch (result.getStatus()) {
                        case OK : {
                            myNetData.flip();
                            while (myNetData.hasRemaining()) {
                                int limit = myNetData.limit();
                                byte[] data = new byte[limit+1];
                                myNetData.get(data, 0, limit);
                                outputStream.write(data);
                                myNetData.position(limit);
                                Log.d(TAG,"MyNetData Sent : "+limit);
                            }
                            Log.d(TAG,"-----NEED_WARP Finished");
                            break;
                        }
                        case BUFFER_OVERFLOW : // Will occur if there is not enough space in myNetData buffer to write all the data that would be generated by the method wrap.
                            // Since myNetData is set to session's packet size we should not get to this point because SSLEngine is supposed
                            // to produce messages smaller or equal to that, but a general handling would be the following:
                            myNetData = enlargePacketBuffer(engine, myNetData);
                            break;
                        case BUFFER_UNDERFLOW :
                            throw new SSLException("Buffer underflow occured after a wrap. I don't think we should ever get here.");
                        case CLOSED : {
                            try {
                                myNetData.flip();
                                while (myNetData.hasRemaining()) {
                                    int limit = myNetData.limit();
                                    byte[] data = new byte[limit];
                                    myNetData.get(data, 0, limit);
                                    outputStream.write(data);
                                    myNetData.position(limit);
                                }
                                // At this point the handshake status will probably be NEED_UNWRAP so we make sure that peerNetData is clear to read.
                                peerNetData.clear();
                            } catch (Exception e) {
                                //  log.error("Failed to send server's CLOSE message due to socket channel's failure.");
                                handshakeStatus = engine.getHandshakeStatus();
                            }
                            break;
                        }
                        default : throw new IllegalStateException("Invalid SSL status: " + result.getStatus());
                    }
                    break;
                }
                case NEED_TASK : {
                    Runnable task;
                    while ((task = engine.getDelegatedTask()) != null) {
                        executor.execute(task);
                    }
                    handshakeStatus = engine.getHandshakeStatus();
                    Log.d(TAG,"NEED_TASK Finished");
                    break;
                }
                case FINISHED :
                case NOT_HANDSHAKING : {
                    break;
                }
                default : throw new IllegalStateException("Invalid SSL status: " + handshakeStatus);
            }
        }
        return true;
    }
    protected ByteBuffer enlargePacketBuffer(SSLEngine engine, ByteBuffer buffer) {
        return enlargeBuffer(buffer, engine.getSession().getPacketBufferSize());
    }
    protected ByteBuffer enlargeApplicationBuffer(SSLEngine engine, ByteBuffer buffer) {
        return enlargeBuffer(buffer, engine.getSession().getApplicationBufferSize());
    }
    protected ByteBuffer enlargeBuffer(ByteBuffer buffer, int sessionProposedCapacity) {
        if (sessionProposedCapacity > buffer.capacity()) {
            buffer = ByteBuffer.allocate(sessionProposedCapacity);
        } else {
            buffer = ByteBuffer.allocate(buffer.capacity() * 2);
        }
        return buffer;
    }
    protected ByteBuffer handleBufferUnderflow(SSLEngine engine, ByteBuffer buffer) {
        if (engine.getSession().getPacketBufferSize() < buffer.limit()) {
            return buffer;
        } else {
            ByteBuffer replaceBuffer = enlargePacketBuffer(engine, buffer);
            buffer.flip();
            replaceBuffer.put(buffer);
            return replaceBuffer;
        }
    }

    public KeyManager[] createKeyManagers(AssetManager assetManager, String filepath, String keystorePassword, String keyPassword) throws Exception {
        //KeyStore keyStore = KeyStore.getInstance("JKS");
        //KeyStore keyStore = KeyStore.getInstance("PKCS12");
        KeyStore keyStore = KeyStore.getInstance(KeyStore.getDefaultType());
        InputStream keyStoreIS = assetManager.open(filepath);
        try {
            keyStore.load(keyStoreIS, keystorePassword.toCharArray());
        } finally {
            //  if (keyStoreIS != null) {
            //    keyStoreIS.close();
            // }
        }
        KeyManagerFactory kmf = KeyManagerFactory.getInstance(KeyManagerFactory.getDefaultAlgorithm());
        kmf.init(keyStore, keyPassword.toCharArray());
        return kmf.getKeyManagers();
    }

    public TrustManager[] createTrustManagers(AssetManager assetManager, String filepath, String keystorePassword) throws Exception {
        //KeyStore trustStore = KeyStore.getInstance("JKS");
        //KeyStore trustStore = KeyStore.getInstance("PKCS12");
        KeyStore trustStore = KeyStore.getInstance(KeyStore.getDefaultType());
        InputStream trustStoreIS = assetManager.open(filepath);
        try {
            trustStore.load(trustStoreIS, keystorePassword.toCharArray());
        } finally {
            //   if (trustStoreIS != null) {
            //      trustStoreIS.close();
            // }
        }
        TrustManagerFactory trustFactory = TrustManagerFactory.getInstance(TrustManagerFactory.getDefaultAlgorithm());
        trustFactory.init(trustStore);
        return trustFactory.getTrustManagers();
    }

    protected void closeConnection(InputStream inputStream, OutputStream outputStream, SSLEngine engine) throws IOException  {
        try {
            engine.closeOutbound();
            doHandshake(inputStream, outputStream, engine);
        } catch (IOException e) {
            throw new RuntimeException(e);
        }
    }

    protected void handleEndOfStream(InputStream inputStream, OutputStream outputStream, SSLEngine engine) throws IOException  {
        try {
            engine.closeInbound();
        } catch (SSLException e) {
            //  log.error("This engine was forced to close inbound, without having received the proper SSL/TLS close notification message from the peer, due to end of stream.");
        }
        closeConnection(inputStream, outputStream, engine);
    }

}
