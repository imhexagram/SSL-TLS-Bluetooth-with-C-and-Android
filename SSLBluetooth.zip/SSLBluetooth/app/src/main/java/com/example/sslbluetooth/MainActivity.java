package com.example.sslbluetooth;

import androidx.appcompat.app.AppCompatActivity;
import androidx.core.app.ActivityCompat;

import android.Manifest;
import android.bluetooth.BluetoothAdapter;
import android.bluetooth.BluetoothDevice;
import android.bluetooth.BluetoothSocket;
import android.content.Context;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.content.res.AssetManager;
import android.os.AsyncTask;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

import java.io.BufferedReader;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.io.OutputStream;
import java.lang.reflect.InvocationTargetException;
import java.lang.reflect.Method;
import java.net.Socket;
import java.nio.charset.StandardCharsets;
import java.security.KeyStore;
import java.security.NoSuchAlgorithmException;
import java.security.SecureRandom;
import java.util.UUID;
import java.util.Set;

import javax.net.ssl.KeyManager;
import javax.net.ssl.KeyManagerFactory;
import javax.net.ssl.SSLContext;
import javax.net.ssl.SSLEngine;
import javax.net.ssl.SSLEngineResult;
import javax.net.ssl.SSLException;
import javax.net.ssl.SSLSession;
import javax.net.ssl.SSLSocket;
import javax.net.ssl.SSLSocketFactory;
import javax.net.ssl.TrustManager;
import javax.net.ssl.TrustManagerFactory;

import java.nio.ByteBuffer;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

public class MainActivity extends AppCompatActivity {

    private BluetoothAdapter bluetoothAdapter;
    private BluetoothSocket bluetoothSocket;
    private InputStream inputStream;
    private OutputStream outputStream;
    private static final String TAG = "MTAG";
    protected ByteBuffer myNetData;
    protected ByteBuffer peerNetData;
    protected ExecutorService executor = Executors.newSingleThreadExecutor();
    private NioSslClient nioSslClient;
    public AssetManager assetManager;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        bluetoothAdapter = BluetoothAdapter.getDefaultAdapter();
        if (bluetoothAdapter == null) {
            Toast.makeText(MainActivity.this, "No Bluetooth Device Found", Toast.LENGTH_SHORT).show();
            finish();
        } else {
            if (!bluetoothAdapter.isEnabled()) {
                if (ActivityCompat.checkSelfPermission(this, android.Manifest.permission.BLUETOOTH_CONNECT) != PackageManager.PERMISSION_GRANTED) {
                    ActivityCompat.requestPermissions(this, new String[]{Manifest.permission.BLUETOOTH_CONNECT}, 123);
                    return;
                }
                Intent enableBtIntent = new Intent(BluetoothAdapter.ACTION_REQUEST_ENABLE);
                startActivity(enableBtIntent);
            }
        }

        checkDevices(bluetoothAdapter);

        BluetoothDevice device = bluetoothAdapter.getRemoteDevice("30:03:C8:AC:9F:50");
        try {
            Method m = device.getClass().getMethod("createRfcommSocket", new Class[]{int.class});
            bluetoothSocket = (BluetoothSocket) m.invoke(device, 20);

            ConnectThread connectThread = new ConnectThread(bluetoothSocket);
            connectThread.start();
            inputStream = connectThread.getInputStream();
            outputStream = connectThread.getOutputStream();
            nioSslClient = connectThread.getNioSslClient();
        } catch (NoSuchMethodException | InvocationTargetException | IllegalAccessException |
                 IOException e) {
            Log.e(TAG, "Error", e);
            throw new RuntimeException(e);
        }
    }

    private class ConnectThread extends Thread {
        private BluetoothSocket socket;

        private boolean activeConnect;

        public ConnectThread(BluetoothSocket bluetoothSocket) {
            this.socket = bluetoothSocket;
        }

        public void run() {
            try {
                if (ActivityCompat.checkSelfPermission(MainActivity.this, Manifest.permission.BLUETOOTH_CONNECT) != PackageManager.PERMISSION_GRANTED) {
                    ActivityCompat.requestPermissions(MainActivity.this, new String[]{Manifest.permission.BLUETOOTH_CONNECT}, 123);
                    //return;
                }
                socket.connect();
                Log.d(TAG, "Bluetooth Connected");
            } catch (IOException e) {
                Log.e(TAG, "Error connecting to bluetooth server", e);
            }
            assetManager = getAssets();
            try {
                nioSslClient = new NioSslClient(socket, assetManager, "TLSv1.3","",20);
                nioSslClient.connect();
                Log.d(TAG,"SSL Connected");
            } catch (Exception e) {
                Log.e(TAG,"Error connecting to SSL server", e);
            }
            while(true){
                try {
                    TextView received = findViewById(R.id.recv);
                    nioSslClient.read(received);
                } catch (Exception e) {
                    throw new RuntimeException(e);
                }
            }
            /*
            try {
                inputStream = socket.getInputStream();

                byte[] buffer = new byte[1024];
                int bytes;
                while(true){
                    bytes = inputStream.read(buffer);
                    if (bytes > 0){
                        final byte[] data = new byte[bytes];
                        System.arraycopy(buffer, 0, data, 0, bytes);
                        String receivedString = new String(data, StandardCharsets.UTF_8);
                        Log.d(TAG,"Recv: "+receivedString);
                        TextView received = findViewById(R.id.recv);
                        received.post(new Runnable() {
                            @Override
                            public void run() {
                                received.setText(received.getText().toString()+receivedString);
                            }
                        });
                    }else{
                        break;
                    }
                }
            } catch (IOException e) {
                throw new RuntimeException(e);
            }
            */
        }
        public InputStream getInputStream() throws IOException {
            return socket.getInputStream();
        }

        public OutputStream getOutputStream() throws IOException {
            return socket.getOutputStream();
        }

        public NioSslClient getNioSslClient() {
            return nioSslClient;
        }
    }

    private void checkDevices(BluetoothAdapter bluetoothAdapter) {
        assert bluetoothAdapter != null;
        if (ActivityCompat.checkSelfPermission(this, Manifest.permission.BLUETOOTH_CONNECT) != PackageManager.PERMISSION_GRANTED) {
            ActivityCompat.requestPermissions(this, new String[]{Manifest.permission.BLUETOOTH_CONNECT}, 123);
            return;
        }
        Set<BluetoothDevice> pairedDevices = bluetoothAdapter.getBondedDevices();
        if (pairedDevices.size() >0 ){
            for (BluetoothDevice device : pairedDevices){
                String deviceName = device.getName();;
                String deviceAddress = device.getAddress();
                Log.d(TAG, deviceName+" "+ deviceAddress);
            }
        }
    }

    public void send(View view){
        EditText sendText = findViewById(R.id.sendText);
        String userInput = sendText.getText().toString();
        Toast.makeText(MainActivity.this, userInput, Toast.LENGTH_SHORT).show();
        //connectedThread.write(userInput.getBytes());
        try{
            //outputStream.write(userInput.getBytes());
            nioSslClient.write(userInput);
            Log.d(TAG, "User Input : "+ userInput);
        } catch (IOException e) {
            Log.e(TAG, "Could not send message");
        }
        TextView sent = findViewById(R.id.sent);
        sent.setText(sent.getText().toString()+"\n"+userInput);
        sendText.getText().clear();
    }
}